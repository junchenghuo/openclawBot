#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
图片分析器技能脚本
分析图片内容，识别物体、场景、文字，并进行图片筛查
"""

import json
import sys
import os
import base64
import requests
from PIL import Image
import io

def load_params():
    """从命令行参数或标准输入加载参数"""
    if len(sys.argv) < 2:
        try:
            params = json.loads(sys.stdin.read())
            return params
        except:
            print("错误：无法读取参数", file=sys.stderr)
            sys.exit(1)
    else:
        try:
            params = json.loads(sys.argv[1])
            return params
        except:
            print("错误：参数JSON格式无效", file=sys.stderr)
            sys.exit(1)

def download_image(image_url):
    """下载图片到本地"""
    try:
        if image_url.startswith('http'):
            response = requests.get(image_url, timeout=30)
            response.raise_for_status()
            return Image.open(io.BytesIO(response.content))
        elif os.path.exists(image_url):
            return Image.open(image_url)
        else:
            raise ValueError(f"无法访问图片: {image_url}")
    except Exception as e:
        raise Exception(f"下载图片失败: {str(e)}")

def analyze_with_vision_api(image, analysis_type, custom_prompt=None, language='zh'):
    """使用多模态 LLM API 分析图片"""
    try:
        # 将图片转换为 base64
        buffered = io.BytesIO()
        if image.mode in ('RGBA', 'LA', 'P'):
            image = image.convert('RGB')
        image.save(buffered, format="JPEG", quality=85)
        img_base64 = base64.b64encode(buffered.getvalue()).decode()
        
        # 构建提示词
        prompts = {
            'general': f"请详细描述这张图片的内容。包括：1) 整体场景描述 2) 主要物体和人物 3) 颜色、光线、氛围 4) 可能的背景信息。请用{language}回答。",
            'objects': f"请识别这张图片中的所有物体。对于每个物体，提供：1) 物体名称 2) 在图片中的大致位置 3) 置信度（0-1）。请用{language}回答。",
            'text': f"请提取这张图片中的所有文字内容。保持原有的格式和布局。如果图片中没有文字，请说明。请用图片中文字的原始语言回答。",
            'faces': f"请分析这张图片中的人脸。对于每张人脸：1) 年龄段估计 2) 性别 3) 表情 4) 是否戴眼镜等特征。请严格保护隐私，仅作技术描述。",
            'moderation': f"请审核这张图片是否包含不当内容。检查：1) 暴力/血腥 2) 成人/色情内容 3) 仇恨符号 4) 其他违规内容。给出是否适当的结论（true/false）和详细说明。",
            'custom': custom_prompt or f"请详细分析这张图片。{language}"
        }
        
        prompt = prompts.get(analysis_type, prompts['general'])
        
        # 这里应该调用实际的多模态 LLM API
        # 示例使用 OpenAI Vision API 格式
        api_key = os.environ.get('OPENAI_API_KEY')
        if not api_key:
            # 模拟返回结果用于演示
            return generate_mock_result(analysis_type, language)
        
        # 实际 API 调用（这里使用示例格式）
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": "gpt-4-vision-preview",
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{img_base64}"
                            }
                        }
                    ]
                }
            ],
            "max_tokens": 1000
        }
        
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers=headers,
            json=payload,
            timeout=60
        )
        
        response.raise_for_status()
        result = response.json()
        analysis_text = result['choices'][0]['message']['content']
        
        return {
            'success': True,
            'analysis_type': analysis_type,
            'description': analysis_text,
            'language': language
        }
        
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'analysis_type': analysis_type
        }

def generate_mock_result(analysis_type, language):
    """生成模拟结果（用于演示或测试）"""
    mock_results = {
        'general': {
            'description': '这是一张示例图片，显示了一个现代化的办公环境。图片中有明亮的窗户、简洁的家具和绿植装饰。整体氛围专业且舒适。' if language == 'zh' else 'This is a sample image showing a modern office environment with bright windows, minimalist furniture, and green plants. The overall atmosphere is professional and comfortable.'
        },
        'objects': {
            'objects': [
                {'name': '桌子', 'confidence': 0.95},
                {'name': '椅子', 'confidence': 0.92},
                {'name': '电脑', 'confidence': 0.88},
                {'name': '植物', 'confidence': 0.85}
            ]
        },
        'text': {
            'text': '示例文字内容\nSample Text Content' if language == 'zh' else 'Sample Text Content'
        },
        'moderation': {
            'is_appropriate': True,
            'flags': [],
            'confidence': 0.98
        }
    }
    
    result = mock_results.get(analysis_type, mock_results['general'])
    result['success'] = True
    result['analysis_type'] = analysis_type
    result['language'] = language
    result['note'] = '这是模拟结果，实际使用需要配置OPENAI_API_KEY环境变量'
    
    return result

def main():
    try:
        params = load_params()
        
        # 获取参数
        image_url = params.get('image_url')
        analysis_type = params.get('analysis_type', 'general')
        custom_prompt = params.get('custom_prompt')
        language = params.get('language', 'zh')
        screening_criteria = params.get('screening_criteria', {})
        
        if not image_url:
            raise ValueError("必须提供image_url参数")
        
        # 下载图片
        image = download_image(image_url)
        
        # 处理筛查模式
        if analysis_type == 'moderation' and screening_criteria:
            # 执行详细的筛查分析
            result = analyze_with_vision_api(image, 'moderation', None, language)
            result['screening_criteria'] = screening_criteria
        else:
            # 执行常规分析
            result = analyze_with_vision_api(image, analysis_type, custom_prompt, language)
        
        # 添加图片基本信息
        result['image_info'] = {
            'width': image.width,
            'height': image.height,
            'mode': image.mode,
            'format': image.format if hasattr(image, 'format') else 'unknown'
        }
        
        print(json.dumps(result, ensure_ascii=False, indent=2))
        
    except Exception as e:
        error_result = {
            "success": False,
            "error": str(e),
            "error_type": type(e).__name__,
            "message": f"图片分析失败: {str(e)}"
        }
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)

if __name__ == "__main__":
    main()
